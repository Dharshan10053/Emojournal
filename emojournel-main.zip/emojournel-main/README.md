# emojournel
Emojournal is a chat-based emotional journaling app using a local AI model for emotion detection. It tracks moods through daily chats, visualizes trends, offers calming content, and supports therapist booking. Built with React, Tailwind CSS, Node.js, and Express.js for better mental wellness.
